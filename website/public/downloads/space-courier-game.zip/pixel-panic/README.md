# Space Courier

Requires Python 3.10+.

From this directory:

python -m pip install -r requirements.txt
python main.py

Move with A/D or arrows. Enter starts, Escape pauses, R restarts, M toggles audio.

This archive contains human gameplay. Download the complete source for AI mode.
