"""Pixel Panic arcade game."""
